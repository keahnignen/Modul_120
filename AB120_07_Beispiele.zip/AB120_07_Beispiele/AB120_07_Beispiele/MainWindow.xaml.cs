﻿using System;
using System.Windows;
using System.Windows.Media;

namespace AB120_07_Beispiele
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        private LoginMeldung validiereLogin()
        {
            LoginMeldung resultat = new LoginMeldung();
            resultat.Resultat = false;
            resultat.Fall = 0;
            resultat.Meldung = "Allgemeiner Fehler";
            // Simulation
            String gueltigerBenutzer = "Hans";
            String gueltigesPasswort = "1234";
            if (benutzer.Text == "")
            {
                resultat.Fall = 1;
                resultat.Meldung = "Benutzer darf nicht leer sein";
            } else if (benutzer.Text != gueltigerBenutzer)
            {
                if (passwortVergessen.IsChecked == false)
                {
                    resultat.Fall = 2;
                    resultat.Meldung = "Benutzer/Passwort falsch";
                }
                else
                {
                    resultat.Fall = 4;
                    resultat.Meldung = "Benutzer ungültig";
                }
            } else if (benutzer.Text == gueltigerBenutzer)
            {
                if (passwortVergessen.IsChecked == false)
                {
                    if (passwort.Password == gueltigesPasswort)
                    {
                        resultat.Fall = 3;
                        resultat.Meldung = "Login korrekt";
                        resultat.Resultat = true;
                    }
                    else
                    {
                        resultat.Fall = 2;
                        resultat.Meldung = "Benutzer/Passwort falsch";
                    }
                } else
                {
                    resultat.Fall = 5;
                    resultat.Meldung = "Passwort an Email gesendet";
                    resultat.Resultat = true;
                }
            }
            return resultat;
        }

        private void ok_Click(object sender, RoutedEventArgs e)
        {
            LoginMeldung loginmeldung = validiereLogin();
            meldung.Content = loginmeldung.Meldung;
            if (loginmeldung.Resultat)
            {
                meldung.Foreground = new SolidColorBrush(Colors.Green);
            } else
            {
                meldung.Foreground = new SolidColorBrush(Colors.Red);
            }
        }
    }

    class LoginMeldung
    {
        public Boolean Resultat { get; set; }
        public byte Fall { get; set; }
        public String Meldung { get; set; }
    }
}
