﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ab120_03_Uebung_Einzelansicht
{
    /// <summary>
    /// Interaktionslogik für Einzelansicht_Kunde_mit_Scrolling.xaml
    /// </summary>
    public partial class Einzelansicht_Kunde_mit_Scrolling : Window
    {
        enum Module
        {
            Leer,
            Kunden,
            Reisen,
            Hotels,
            Listen,
            Einstellungen
        }
        private Module aktuellesModul;
        public Einzelansicht_Kunde_mit_Scrolling()
        {
            InitializeComponent();
            aktuellesModul = Module.Leer;
        }

        private void zeigeKunden_Click(object sender, RoutedEventArgs e)
        {
            if (aktuellesModul != Module.Kunden)
            {
                aktuellesModul = Module.Kunden;
                UC_Listenansicht_Kunde kunde = new UC_Listenansicht_Kunde(inhalt); //AB06 A2
                kunde.HorizontalAlignment = HorizontalAlignment.Left;
                kunde.VerticalAlignment = VerticalAlignment.Top;
                inhalt.Content = null;
                inhalt.Content = kunde;
            }
        }
        private void zeigeReisen_Click(object sender, RoutedEventArgs e)
        {
            if (aktuellesModul != Module.Reisen)
            {
                aktuellesModul = Module.Reisen;
                zeige_Dummy("REISEN");
            }
        }
        private void zeigeHotels_Click(object sender, RoutedEventArgs e)
        {
            if (aktuellesModul != Module.Hotels)
            {
                aktuellesModul = Module.Hotels;
                zeige_Dummy("HOTELS");
            }
        }
        private void zeigeListen_Click(object sender, RoutedEventArgs e)
        {
            if (aktuellesModul != Module.Listen)
            {
                aktuellesModul = Module.Listen;
                zeige_Dummy("LISTEN");
            }
        }
        private void zeigeEinstellungen_Click(object sender, RoutedEventArgs e)
        {
            if (aktuellesModul != Module.Einstellungen)
            {
                aktuellesModul = Module.Einstellungen;
                zeige_Dummy("EINSTELLUNGEN");
            }
        }
        private void zeige_Dummy(String anzeige)
        {
            Dummy dummy = new Dummy(anzeige);
            dummy.HorizontalAlignment = HorizontalAlignment.Left;
            dummy.VerticalAlignment = VerticalAlignment.Top;
            inhalt.Content = null;
            inhalt.Content = dummy;
        }
    }
}
