﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ab120_03_Uebung_Einzelansicht
{
    /// <summary>
    /// Interaktionslogik für UC_Einzelansicht_Kunde.xaml
    /// </summary>
    public partial class UC_Einzelansicht_Kunde : UserControl
    {
        #region "Klassenvariablen"
        enum Zustand
        {
            Leer,
            Anzeige,
            Neu,
            Veraendert,
            Ungespeichert
        }
        enum Uebergang
        {
            Abbrechen,
            Suchen,
            Erstellen,
            Loeschen,
            Eingabe,
            Speichern
        }
        private Boolean eingabeIgnorieren;
        private Zustand aktuellerZustand;
        private Zustand AktuellerZustand
        {
            get { return aktuellerZustand; }
            // Knöpfe ein/ausschalten je nach Zustand
            set
            {
                if (value == Zustand.Leer)
                {
                    DeaktiviereSteuerelemente();
                    sucheNr.IsEnabled = true;
                    suchen.IsEnabled = true;
                    neu.IsEnabled = true;
                    aktuellerZustand = value;
                    // GUI
                    LeereFelder();
                    EinzelansichtGrid.IsEnabled = false;
                }
                else if (value == Zustand.Anzeige)
                {
                    DeaktiviereSteuerelemente();
                    abbrechen.IsEnabled = true;
                    neu.IsEnabled = true;
                    loeschen.IsEnabled = true;
                    aktuellerZustand = value;
                    // Felder abfüllen
                    eingabeIgnorieren = true;
                    LeereFelder();
                    EinzelansichtGrid.IsEnabled = true;
                    if (kunde.Anrede.Equals("Herr"))
                    {
                        anredeHerr.IsChecked = true;
                    } else if(kunde.Anrede.Equals("Frau"))
                    {
                        anredeFrau.IsChecked = true;
                    } else if (kunde.Anrede.Equals("Familie"))
                    {
                        anredeFamilie.IsChecked = true;
                    }
                    tbVorname.Text = kunde.Vorname;
                    tbName.Text = kunde.Name;
                    tbNameZusatz.Text = kunde.NameZusatz;
                    tbPLZ.Text = kunde.PLZ.ToString();
                    tbOrt.Text = kunde.Ort;
                    tbTel.Text = kunde.Telefon;
                    tbMobile.Text = kunde.Mobile;
                    tbEmail.Text = kunde.Email;
                    tbWeb.Text = kunde.Web;
                    // AB06 A1 START
                    if (kunde.Nationalitaet != 0)
                    {
                        LandSelektieren(kunde.Nationalitaet);
                    } else
                    {
                        cbLand.SelectedIndex = -1;
                    }
                    // AB06 A1 ENDE
                    // AB06 A3 START
                    imgLand.Source = APP.Land.BitmapImageFromBytes(APP.Land.Lesen_LandID((long)cbLand.SelectedValue).Flagge);
                    // AB06 A3 ENDE
                    eingabeIgnorieren = false;
                }
                else if (value == Zustand.Veraendert)
                {
                    DeaktiviereSteuerelemente();
                    abbrechen.IsEnabled = true;
                    speichern.IsEnabled = true;
                    aktuellerZustand = value;
                } else if (value == Zustand.Neu)
                {
                    DeaktiviereSteuerelemente();
                    EinzelansichtGrid.IsEnabled = true;
                    abbrechen.IsEnabled = true;
                    aktuellerZustand = value;
                } else if (value == Zustand.Ungespeichert)
                {
                    DeaktiviereSteuerelemente();
                    abbrechen.IsEnabled = true;
                    speichern.IsEnabled = true;
                    aktuellerZustand = value;
                }
            }
        }
        private DB.Kunde kunde;
        private ScrollViewer parentControl;
        #endregion
        public UC_Einzelansicht_Kunde(long kundeID, ScrollViewer parent) //AB06 A2 mit Parametern
        {
            InitializeComponent();
            AktuellerZustand = Zustand.Leer;
            // AB06 A1
            cbLand.ItemsSource = APP.Land.Lesen_Alle();
            cbLand.DisplayMemberPath = "Name";
            cbLand.SelectedValuePath = "LandID";
            // AB06 A2
            sucheNr.Text = kundeID.ToString();
            macheUebergang(Uebergang.Suchen);
            parentControl = parent;
        }
        private void macheUebergang(Uebergang uebergang)
        {
            if(uebergang == Uebergang.Abbrechen)
            {
                if (aktuellerZustand == Zustand.Veraendert || aktuellerZustand == Zustand.Ungespeichert)
                {
                    if (MessageBox.Show("Änderungen gehen verloren, wirklich abbrechen?", "Achtung!", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No) == MessageBoxResult.Yes)
                    {
                        Abbrechen();
                    }
                }
                else
                {
                    Abbrechen();
                }
            } else if (uebergang == Uebergang.Erstellen)
            {
                Erstellen();
            } else if (uebergang == Uebergang.Loeschen)
            {
                if (MessageBox.Show("Wirklich löschen?", "Achtung", MessageBoxButton.YesNo , MessageBoxImage.Warning, MessageBoxResult.No) == MessageBoxResult.Yes)
                {
                    AblaufLoeschen();
                }
            } else if (uebergang == Uebergang.Suchen)
            {
                if (sucheNr.Text.Length > 0)
                {
                    AblaufSuchen();
                } else
                {
                    MessageBox.Show("Bitte Kundennummer eingeben", "Fehler", MessageBoxButton.OK, MessageBoxImage.Exclamation, MessageBoxResult.OK);
                }
            } else if (uebergang == Uebergang.Eingabe)
            {
                AblaufEingabe();
            } else if (uebergang == Uebergang.Speichern)
            {
                AblaufSpeichern();
            }
        }
        #region "Schnittstelle zu Applikationsschicht"
        private void Abbrechen()
        {
            // DB
            kunde = null;
            // GUI
            AktuellerZustand = Zustand.Leer;
            // AB06 A2
            parentControl.Content = new UC_Listenansicht_Kunde(parentControl);
        }
        private void Erstellen()
        {
            // DB
            kunde = new DB.Kunde();
            // GUI
            LeereFelder();
            AktuellerZustand = Zustand.Neu;
        }
        private void AblaufLoeschen()
        {
            // DB
            APP.Kunde.Loeschen(kunde);
            // GUI
            AktuellerZustand = Zustand.Leer;
            // AB06 A2
            parentControl.Content = new UC_Listenansicht_Kunde(parentControl);

        }
        private void AblaufSuchen()
        {
            // DB
            kunde = APP.Kunde.Lesen_KundeID(Convert.ToInt64(sucheNr.Text));
            //TODO: wenn nichts gefunden
            if (kunde == null)
            {
                MessageBox.Show("Kein Kunde gefunden", "Info", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.OK);
                AktuellerZustand = Zustand.Leer;
            } else
            {
                // GUI
                AktuellerZustand = Zustand.Anzeige;
            }
        }
        private void AblaufSpeichern()
        {
            // Auslesen
            if (anredeHerr.IsChecked == true)
            {
                kunde.Anrede = "Herr";
            } else if (anredeFrau.IsChecked == true)
            {
                kunde.Anrede = "Frau";
            } else if (anredeFamilie.IsChecked == true)
            {
                kunde.Anrede = "Familie";
            }
            kunde.Vorname = tbVorname.Text;
            kunde.Name = tbName.Text;
            kunde.NameZusatz = tbNameZusatz.Text;
            try
            {
                kunde.PLZ = Convert.ToInt16(tbPLZ.Text);
            } catch (Exception ex)
            {
                kunde.PLZ = 0;
            }
            kunde.Ort = tbOrt.Text;
            kunde.Telefon = tbTel.Text;
            kunde.Mobile = tbMobile.Text;
            kunde.Email = tbEmail.Text;
            kunde.Web = tbWeb.Text;
            // AB06 A1 START
            if (cbLand.SelectedValue != null)
            {
                kunde.Nationalitaet = (long)cbLand.SelectedValue;
            }
            // AB06 A1 ENDE
            // DB
            if (aktuellerZustand == Zustand.Ungespeichert)
            {
                // Neu hinzufügen
                APP.Kunde.Erstellen(kunde);
            } else if (aktuellerZustand == Zustand.Veraendert)
            {
                // Aenderungen speichern
                APP.Kunde.Aktualisieren(kunde);
            }
            // GUI
            AktuellerZustand = Zustand.Anzeige;

        }
        private void AblaufEingabe()
        {
            // DB (leer)
            // GUI
            if (AktuellerZustand == Zustand.Anzeige || AktuellerZustand == Zustand.Veraendert)
            {
                AktuellerZustand = Zustand.Veraendert;
            } else if (AktuellerZustand == Zustand.Neu)
            {
                AktuellerZustand = Zustand.Ungespeichert;
            }
        }
        #endregion
        #region "GUI Ereignisse"
        private void suchen_Click(object sender, RoutedEventArgs e)
        {
            macheUebergang(Uebergang.Suchen);
        }
        private void sucheNr_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                macheUebergang(Uebergang.Suchen);
            }
        }
        private void speichern_Click(object sender, RoutedEventArgs e)
        {
            macheUebergang(Uebergang.Speichern);
        }
        private void eingabe(object sender, TextChangedEventArgs e)
        {
            if (!eingabeIgnorieren)
            {
                macheUebergang(Uebergang.Eingabe);
            }
        }
        private void anredeFrau_Checked(object sender, RoutedEventArgs e)
        {
            if (!eingabeIgnorieren)
            {
                macheUebergang(Uebergang.Eingabe);
            }
        }
        private void anredeHerr_Checked(object sender, RoutedEventArgs e)
        {
            if (!eingabeIgnorieren)
            {
                macheUebergang(Uebergang.Eingabe);
            }
        }
        private void anredeFamilie_Checked(object sender, RoutedEventArgs e)
        {
            if (!eingabeIgnorieren)
            {
                macheUebergang(Uebergang.Eingabe);
            }
        }
        private void neu_Click(object sender, RoutedEventArgs e)
        {
            macheUebergang(Uebergang.Erstellen);
        }
        private void loeschen_Click(object sender, RoutedEventArgs e)
        {
            macheUebergang(Uebergang.Loeschen);
        }
        private void abbrechen_Click(object sender, RoutedEventArgs e)
        {
            macheUebergang(Uebergang.Abbrechen);
        }
        //AB06 A1
        private void cbLand_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!eingabeIgnorieren)
            {
                macheUebergang(Uebergang.Eingabe);
                // AB06 A3 START
                if (cbLand.SelectedValue != null)
                {
                imgLand.Source = APP.Land.BitmapImageFromBytes(APP.Land.Lesen_LandID((long)cbLand.SelectedValue).Flagge);
                }
                // AB06 A3 ENDE
            }
        }
        #endregion
        #region "GUI Hilfsfunktionen"
        private void DeaktiviereSteuerelemente()
        {
            suchen.IsEnabled = false;
            sucheNr.IsEnabled = false;
            speichern.IsEnabled = false;
            neu.IsEnabled = false;
            loeschen.IsEnabled = false;
            abbrechen.IsEnabled = false;
        }
        private void LeereFelder()
        {
            anredeHerr.IsChecked = false;
            anredeFrau.IsChecked = false;
            anredeFamilie.IsChecked = false;
            tbVorname.Text = "";
            tbName.Text = "";
            tbNameZusatz.Text = "";
            tbPLZ.Text = "";
            tbOrt.Text = "";
            tbTel.Text = "";
            tbMobile.Text = "";
            tbEmail.Text = "";
            tbWeb.Text = "";
            tbPassNr.Text = "";
            // AB06 A1
            cbLand.SelectedIndex = -1;
        }
        #endregion

        // AB06 A1
        private void LandSelektieren(long landID)
        {            
            cbLand.SelectedValue = landID;
        }
    }
}
