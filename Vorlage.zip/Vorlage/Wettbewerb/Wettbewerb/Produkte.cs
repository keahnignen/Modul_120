﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wettbewerb
{
    public class Produkte
    {
        public String Name1;
        public String Name2;
        public String Name3;
        public String Name4;
        public String Name5;
        public Int16 Stimmen1;
        public Int16 Stimmen2;
        public Int16 Stimmen3;
        public Int16 Stimmen4;
        public Int16 Stimmen5;
    }
}
